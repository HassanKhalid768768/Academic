import heapq
from collections import deque

class Cell(object):
    """A cell class for A* Pathfinding"""

    def __init__(self, x, y, reachable):
        """
        Initialize new cell
        @param reachable is cell reachable? Not a wall?
        @param x cell x coordinate
        @param y cell y coordinate
        """
        self.reachable = reachable
        self.x = x
        self.y = y
        self.parent = None
        self.g = 0
        self.h = 0
        self.f = 0

    def __lt__(self, other):
        return self.f < other.f

class A_Star_Implementation:
    def __init__(self, state):
        """Initializes the A* algorithm with the game state and the maze map"""
        self.state = state
        self.maze = state.maze.MAP
        self.grid_height = len(self.maze)
        self.grid_width = len(self.maze[0])
        self.opened = []
        heapq.heapify(self.opened)
        self.closed = set()
        self.cells = []
        self.init_grid()

    def heuristic(self, a, b):
        """Calculate the Manhattan distance heuristic between two points"""
        return abs(a.x - b.x) + abs(a.y - b.y)

    def get_cell(self, x, y):
        """Returns a cell from the cells list"""
        return self.cells[x * self.grid_height + y]

    def init_grid(self):
        """Prepare grid cells and identify walls."""
        walls = [(x, y) for x in range(self.grid_width) for y in range(self.grid_height) if self.maze[y][x] == -1]
        start = (self.state.snake.HeadPosition.X, self.state.snake.HeadPosition.Y)
        end = (self.state.FoodPosition.X, self.state.FoodPosition.Y)
        for x in range(self.grid_width):
            for y in range(self.grid_height):
                if (x, y) in walls:
                    reachable = False
                else:
                    reachable = True
                self.cells.append(Cell(x, y, reachable))
        self.start = self.get_cell(*start)
        self.end = self.get_cell(*end)

    def get_adjacent_cells(self, cell):
        """Returns adjacent cells to a cell. Clockwise starting from the one on the right"""
        cells = []
        if cell.x < self.grid_width - 1:
            cells.append(self.get_cell(cell.x + 1, cell.y))
        if cell.y > 0:
            cells.append(self.get_cell(cell.x, cell.y - 1))
        if cell.x > 0:
            cells.append(self.get_cell(cell.x - 1, cell.y))
        if cell.y < self.grid_height - 1:
            cells.append(self.get_cell(cell.x, cell.y + 1))
        return cells

    def update_cell(self, adj, cell):
        """Update adjacent cell"""
        adj.g = cell.g + 10
        adj.h = self.heuristic(adj, self.end)
        adj.parent = cell
        adj.f = adj.h + adj.g

    def a_star_search(self):
        """Executes the A* search algorithm"""
        heapq.heappush(self.opened, (self.start.f, self.start))
        while len(self.opened):
            _, cell = heapq.heappop(self.opened)
            self.closed.add(cell)
            if cell is self.end:
                return self.reconstruct_path()
            adj_cells = self.get_adjacent_cells(cell)
            for adj_cell in adj_cells:
                if adj_cell.reachable and adj_cell not in self.closed:
                    if (adj_cell.f, adj_cell) in self.opened:
                        if adj_cell.g > cell.g + 10:
                            self.update_cell(adj_cell, cell)
                    else:
                        self.update_cell(adj_cell, cell)
                        heapq.heappush(self.opened, (adj_cell.f, adj_cell))

    def reconstruct_path(self):
        """Reconstructs the path from end to start by following the parent links"""
        path = []
        cell = self.end
        while cell.parent is not None:
            path.append((cell.x, cell.y))
            cell = cell.parent
        path.append((self.start.x, self.start.y))
        path.reverse()
        return path

    def convert_path_to_plan(self, path):
        """Converts a path to a plan with directions"""
        plan = []
        for i in range(1, len(path)):
            current, next = path[i - 1], path[i]
            if next[0] == current[0] + 1:
                plan.append(3)  # Right
            elif next[0] == current[0] - 1:
                plan.append(9)  # Left
            elif next[1] == current[1] + 1:
                plan.append(6)  # Down
            elif next[1] == current[1] - 1:
                plan.append(0)  # Up
        return plan

    def SearchSolution(self):
        """Initiates the A* search and returns the movement plan"""
        print("Searching for Solution using A*")
        path = self.a_star_search()
        return self.convert_path_to_plan(path)


class BFS_Implementation:
    def __init__(self, state):
        """Initializes the BFS algorithm with the game state and the maze map"""
        self.state = state
        self.maze = state.maze.MAP
        self.grid_height = len(self.maze)
        self.grid_width = len(self.maze[0])
        self.visited = set()
        self.cells = []
        self.init_grid()

    def get_cell(self, x, y):
        """Returns a cell from the cells list"""
        return self.cells[x * self.grid_height + y]

    def init_grid(self):
        """Prepare grid cells and identify walls."""
        walls = [(x, y) for x in range(self.grid_width) for y in range(self.grid_height) if self.maze[y][x] == -1]
        start = (self.state.snake.HeadPosition.X, self.state.snake.HeadPosition.Y)
        end = (self.state.FoodPosition.X, self.state.FoodPosition.Y)
        for x in range(self.grid_width):
            for y in range(self.grid_height):
                reachable = (x, y) not in walls
                self.cells.append(Cell(x, y, reachable))
        self.start = self.get_cell(*start)
        self.end = self.get_cell(*end)

    def get_adjacent_cells(self, cell):
        """Returns adjacent cells to a cell. Clockwise starting from the one on the right"""
        cells = []
        if cell.x < self.grid_width - 1:
            cells.append(self.get_cell(cell.x + 1, cell.y))
        if cell.y > 0:
            cells.append(self.get_cell(cell.x, cell.y - 1))
        if cell.x > 0:
            cells.append(self.get_cell(cell.x - 1, cell.y))
        if cell.y < self.grid_height - 1:
            cells.append(self.get_cell(cell.x, cell.y + 1))
        return cells

    def bfs_search(self):
        """Executes the BFS search algorithm and returns the end cell if a path is found."""
        queue = deque([self.start])
        self.visited.add(self.start)
        while queue:
            cell = queue.popleft()
            if cell is self.end:
                return cell  # Return the end cell directly
            adj_cells = self.get_adjacent_cells(cell)
            for adj_cell in adj_cells:
                if adj_cell.reachable and adj_cell not in self.visited:
                    queue.append(adj_cell)
                    self.visited.add(adj_cell)
                    adj_cell.parent = cell
        return None  # Return None if no path is found

    def reconstruct_path(self, end_cell):
        """Reconstructs the path from end to start by following the parent links"""
        path = []
        cell = end_cell
        while cell.parent is not None:
            path.append((cell.x, cell.y))
            cell = cell.parent
        path.append((self.start.x, self.start.y))
        path.reverse()
        return path
    def convert_path_to_plan(self, path):
        """Converts a path to a plan with directions. Expecting path as a list of tuples."""
        plan = []
        if not all(isinstance(point, tuple) and len(point) == 2 for point in path):
            print("Error: Path format is incorrect. Expected a list of (x, y) tuples.")
            return plan  # Return an empty plan if the path format is incorrect
        
        for i in range(1, len(path)):
            current, next = path[i - 1], path[i]
            # Direction calculations remain the same
            if next[0] == current[0] + 1:
                plan.append(3)  # Right
            elif next[0] == current[0] - 1:
                plan.append(9)  # Left
            elif next[1] == current[1] + 1:
                plan.append(6)  # Down
            elif next[1] == current[1] - 1:
                plan.append(0)  # Up
        return plan
    
    def SearchSolution(self):
        """Initiates the BFS search and returns the movement plan if a path is found."""
        print("Searching for Solution using BFS")
        end_cell = self.bfs_search()  # Get the end cell from BFS search
        if end_cell:
            path = self.reconstruct_path(end_cell)  # Reconstruct the path from the end cell
            return self.convert_path_to_plan(path)  # Convert the path to movement plan
        else:
            return []

class GreedyBFS_Implementation:
    def __init__(self, state):
        """Initializes the Greedy BFS algorithm with the game state and the maze map"""
        self.state = state
        self.maze = state.maze.MAP
        self.grid_height = len(self.maze)
        self.grid_width = len(self.maze[0])
        self.cells = []
        self.init_grid()

    def heuristic(self, a, b):
        """Calculate the Manhattan distance heuristic between two points"""
        return abs(a.x - b.x) + abs(a.y - b.y)

    def get_cell(self, x, y):
        """Returns a cell from the cells list"""
        return self.cells[x * self.grid_height + y]

    def init_grid(self):
        """Prepare grid cells and identify walls."""
        walls = [(x, y) for x in range(self.grid_width) for y in range(self.grid_height) if self.maze[y][x] == -1]
        start = (self.state.snake.HeadPosition.X, self.state.snake.HeadPosition.Y)
        end = (self.state.FoodPosition.X, self.state.FoodPosition.Y)
        for x in range(self.grid_width):
            for y in range(self.grid_height):
                reachable = (x, y) not in walls
                self.cells.append(Cell(x, y, reachable))
        self.start = self.get_cell(*start)
        self.end = self.get_cell(*end)

    def get_adjacent_cells(self, cell):
        """Returns adjacent cells to a cell. Clockwise starting from the one on the right"""
        cells = []
        if cell.x < self.grid_width - 1:
            cells.append(self.get_cell(cell.x + 1, cell.y))
        if cell.y > 0:
            cells.append(self.get_cell(cell.x, cell.y - 1))
        if cell.x > 0:
            cells.append(self.get_cell(cell.x - 1, cell.y))
        if cell.y < self.grid_height - 1:
            cells.append(self.get_cell(cell.x, cell.y + 1))
        return cells

    def greedy_bfs_search(self):
        """Executes the Greedy BFS search algorithm"""
        frontier = []
        heapq.heappush(frontier, (0, self.start))
        visited = set()

        while frontier:
            _, cell = heapq.heappop(frontier)
            if cell in visited:
                continue

            visited.add(cell)

            if cell == self.end:
                return self.reconstruct_path()

            adj_cells = self.get_adjacent_cells(cell)
            for adj_cell in adj_cells:
                if adj_cell.reachable and adj_cell not in visited:
                    adj_cell.parent = cell
                    heapq.heappush(frontier, (self.heuristic(adj_cell, self.end), adj_cell))

        return []

    def reconstruct_path(self):
        """Reconstructs the path from end to start by following the parent links"""
        path = []
        cell = self.end
        while cell.parent is not None:
            path.append((cell.x, cell.y))
            cell = cell.parent
        path.append((self.start.x, self.start.y))
        path.reverse()
        return path

    def convert_path_to_plan(self, path):
        """Converts a path to a plan with directions"""
        plan = []
        for i in range(1, len(path)):
            current, next = path[i - 1], path[i]
            if next[0] == current[0] + 1:
                plan.append(3)  # Right
            elif next[0] == current[0] - 1:
                plan.append(9)  # Left
            elif next[1] == current[1] + 1:
                plan.append(6)  # Down
            elif next[1] == current[1] - 1:
                plan.append(0)  # Up
        return plan

    def SearchSolution(self):
        """Initiates the Greedy BFS search and returns the movement plan"""
        print("Searching for Solution using Greedy BFS")
        path = self.greedy_bfs_search()
        return self.convert_path_to_plan(path)
    
class Agent(object):
    def SearchSolution(self, state):
        return []
        
class AgentSnake(Agent):
    def SearchSolution(self, state, algorithm="A*"):
        print("AgentSnake searching for solution...")
        if algorithm == "A*":
            solver = A_Star_Implementation(state)
        elif algorithm == "BFS":
            solver = BFS_Implementation(state)
        elif algorithm == "GBFS":
            solver = GreedyBFS_Implementation(state)
        else:
            raise ValueError("Unsupported search algorithm")
        return solver.SearchSolution()
    def showAgent():
        print("A Snake Solver By MB")
