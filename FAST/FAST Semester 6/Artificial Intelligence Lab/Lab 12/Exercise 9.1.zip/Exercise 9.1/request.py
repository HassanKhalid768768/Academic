import requests

url = 'http://localhost:5000/predict_api'

r = requests.post(url,json={'Pclass':20000, 'Sex':4, 'Age':5,'SibSp':2,'Parch':12000, 'Fare':34, 'Embarked_C':34,'Embarked_Q':34,'Embarked_S':43})

print(r.json())