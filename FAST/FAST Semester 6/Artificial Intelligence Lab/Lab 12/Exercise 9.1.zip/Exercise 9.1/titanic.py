#importing important libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import pickle

#importing dataset
titanic_data=pd.read_csv('titanic.csv')

titanic_data

#Interpreting data description
titanic_data.describe()

#imputing the missing values for Age,Fare and Embarked
from sklearn.impute import SimpleImputer

imputer = SimpleImputer(strategy="mean")
titanic_data["Age"] = imputer.fit_transform(titanic_data[["Age"]])

imputer = SimpleImputer(strategy="mean")
titanic_data["Fare"] = imputer.fit_transform(titanic_data[["Fare"]])

#dropping passenger id, name, ticket and cabin column 
titanic_data = titanic_data.drop(['PassengerId', 'Name', 'Ticket','Cabin'], axis=1)

from sklearn.preprocessing import LabelEncoder

label_encoder = LabelEncoder()
titanic_data['Sex'] = label_encoder.fit_transform(titanic_data['Sex'])
titanic_data = pd.get_dummies(titanic_data, columns=["Embarked"])
titanic_data['Embarked_C'] = label_encoder.fit_transform(titanic_data['Embarked_C'])
titanic_data['Embarked_Q'] = label_encoder.fit_transform(titanic_data['Embarked_Q'])
titanic_data['Embarked_S'] = label_encoder.fit_transform(titanic_data['Embarked_S'])

titanic_data

#displaying correlation map to see the correlation between columns of dataset
numeric_data = titanic_data.select_dtypes(include=[int, float])
correlation_matrix = numeric_data.corr()

sns.heatmap(correlation_matrix, annot=True, cmap='YlGnBu', fmt=".2f")
plt.show()

#Using bar graph to see the survived males and females
sns.countplot(x=titanic_data['Sex'],hue=titanic_data['Survived'])

#splitting the dataset into 70-30 ratio for training and testing
from sklearn.model_selection import train_test_split

X = titanic_data.drop('Survived', axis=1) #Selecting the features
y = titanic_data['Survived'] #Selecting the prediction target

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

#Selecting the regressor and training the model
from sklearn.tree import DecisionTreeRegressor

model=DecisionTreeRegressor(random_state=0)
model.fit(X_train, y_train)

# Saving model to disk
pickle.dump(model, open('titanic.pkl','wb'))

# Loading model to compare the results
model = pickle.load(open('titanic.pkl','rb'))