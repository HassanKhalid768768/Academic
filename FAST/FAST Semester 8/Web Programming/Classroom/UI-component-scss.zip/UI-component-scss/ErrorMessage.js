import styles from './Form.module.scss';

function ErrorMessage({ message }) {
  if (!message) return null; // Don't render if no message
  return <div className={styles.error}>{message}</div>;
}

export default ErrorMessage;
