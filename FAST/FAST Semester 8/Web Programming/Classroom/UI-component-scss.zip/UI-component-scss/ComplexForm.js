import { useState } from "react";
import styles from './Form.module.scss';
import ErrorMessage from "./ErrorMessage";  // Import the new component

function ComplexForm() {
  const [formData, setFormData] = useState({
    name: "",
    feedback: "",
    gender: "",
    agree: false,
    favoriteColor: "",
  });

  const [errors, setErrors] = useState({});
  const [submittedData, setSubmittedData] = useState([]);

  function validateForm() {
    let newErrors = {};
    if (!formData.name) newErrors.name = "Name is required.";
    if (!formData.feedback) newErrors.feedback = "Feedback is required.";
    if (!formData.gender) newErrors.gender = "Please select a gender.";
    if (!formData.agree) newErrors.agree = "You must agree to the terms.";
    if (!formData.favoriteColor) newErrors.favoriteColor = "Select a favorite color.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleChange(e) {
    const { name, value, type, checked } = e.target;
    setFormData({ ...formData, [name]: type === "checkbox" ? checked : value });

    setErrors({ ...errors, [name]: "" });
  }

  function handleSubmit(e) {
    e.preventDefault();
    if (!validateForm()) return;

    setSubmittedData([...submittedData, formData]);
    setFormData({ name: "", feedback: "", gender: "", agree: false, favoriteColor: "" });
  }

  function handleReset() {
    setFormData({ name: "", feedback: "", gender: "", agree: false, favoriteColor: "" });
    setErrors({});
  }

  return (
    <div className={styles["form-container"]}>
      <h2>Complex Form</h2>
      <form className={styles.formContainer} onSubmit={handleSubmit}>
        <div className={styles["form-group"]}>
          <label>Name:</label>
          <input type="text" name="name" value={formData.name} onChange={handleChange} />
          <ErrorMessage message={errors.name} />
        </div>

        <div className={styles["form-group"]}>
          <label>Feedback:</label>
          <textarea name="feedback" value={formData.feedback} onChange={handleChange} />
          <ErrorMessage message={errors.feedback} />
        </div>

        <div className={styles["form-group"]}>
          <label>Gender:</label>
          <label>
            <input type="radio" name="gender" value="Male" checked={formData.gender === "Male"} onChange={handleChange} />
            Male
          </label>
          <label>
            <input type="radio" name="gender" value="Female" checked={formData.gender === "Female"} onChange={handleChange} />
            Female
          </label>
          <ErrorMessage message={errors.gender} />
        </div>

        <div className={styles["form-group"]}>
          <label>
            <input type="checkbox" name="agree" checked={formData.agree} onChange={handleChange} />
            I agree to the terms and conditions
          </label>
          <ErrorMessage message={errors.agree} />
        </div>

        <div className={styles["form-group"]}>
          <label>Favorite Color:</label>
          <select name="favoriteColor" value={formData.favoriteColor} onChange={handleChange}>
            <option value="">Select a color</option>
            <option value="Red">Red</option>
            <option value="Blue">Blue</option>
            <option value="Green">Green</option>
          </select>
          <ErrorMessage message={errors.favoriteColor} />
        </div>

        <div className={styles.buttons}>
          <button type="submit" className={styles["btn-submit"]}>Submit</button>
          <button type="button" className={styles["btn-reset"]} onClick={handleReset}>Reset</button>
        </div>
      </form>

      {/* Live Preview */}
      <div className={styles.livePreview}>
        <h3>Live Preview</h3>
        <p><strong>Name:</strong> {formData.name || "N/A"}</p>
        <p><strong>Feedback:</strong> {formData.feedback || "N/A"}</p>
        <p><strong>Gender:</strong> {formData.gender || "N/A"}</p>
        <p><strong>Agreed to Terms:</strong> {formData.agree ? "Yes" : "No"}</p>
        <p><strong>Favorite Color:</strong> {formData.favoriteColor || "N/A"}</p>
      </div>

      {/* Display submitted data */}
      {submittedData.length > 0 && (
        <table className={styles.submittedTable}>
          <thead>
            <tr>
              <th>Name</th>
              <th>Feedback</th>
              <th>Color</th>
              <th>Gender</th>
              <th>Agreed</th>
            </tr>
          </thead>
          <tbody>
            {submittedData.map((data, index) => (
              <tr key={index}>
                <td>{data.name}</td>
                <td>{data.feedback}</td>
                <td>{data.favoriteColor}</td>
                <td>{data.gender}</td>
                <td>{data.agree ? "Yes" : "No"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default ComplexForm;
