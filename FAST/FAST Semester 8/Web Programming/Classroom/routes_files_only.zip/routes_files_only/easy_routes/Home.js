import React from "react";

function Home() {
  return (
    <div className="p-4">
      <h1 className="text-xl font-bold">Welcome to Our Website</h1>
      <p className="mt-2">This is the home page. Click on the links above to navigate.</p>
    </div>
  );
}

export default Home;
