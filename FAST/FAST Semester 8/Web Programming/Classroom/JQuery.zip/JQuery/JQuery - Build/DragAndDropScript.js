$(function() {
    $("#sortable").sortable().disableSelection();
});