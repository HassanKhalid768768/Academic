window.addEventListener("load",initAll,false);

function initAll()
{
	document.getElementById("theForm").addEventListener("submit", addNodeFunc, false);
}

function addNodeFunc(evt)
{	
	var inText = document.getElementById("textArea").value;
	
	
	var newGraf = document.createElement("p");

	// Create a text node 
	var newText = document.createTextNode(inText);
	// Append the text node to the paragraph 
	newGraf.appendChild(newText);


	// Create an ID attribute 
	let idAttr = document.createAttribute("id");
	// Assign a value to the attribute
	idAttr.value = "myPara"; 
	 // Attach the attribute to the paragrah
	newGraf.setAttributeNode(idAttr); 

	// Create an ID attribute 
	let classAttr = document.createAttribute("class");
	// Assign a value to the attribute
	classAttr.value = "myClass"; 
	 // Attach the attribute to the paragrah
	newGraf.setAttributeNode(classAttr); 

	// var newGraf = document.createElement("p");
	// newGraf.textContent = inText;
	

	var docBody = document.getElementsByTagName("body")[0];
	docBody.appendChild(newGraf);
	evt.preventDefault();
}