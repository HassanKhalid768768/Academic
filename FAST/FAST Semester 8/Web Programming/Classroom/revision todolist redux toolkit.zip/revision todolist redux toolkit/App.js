// App.js
import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import { Provider, useDispatch, useSelector } from 'react-redux';
import { configureStore } from '@reduxjs/toolkit';
import TodoPage from './TodoPage';
import ListPage from './ListPage';
import todoReducer from './todoSlice';

// 👉 Store setup inside App.js
const store = configureStore({
  reducer: {
    todos: todoReducer,
  },
});

function App() {
  return (
    <Provider store={store}>
      <Router>
        <nav style={{ padding: 10 }}>
          <Link to="/" style={{ marginRight: 10 }}>Home</Link>
          <Link to="/list">Todo List</Link>
        </nav>
        <Routes>
          <Route path="/" element={<TodoPage />} />
          <Route path="/list" element={<ListPage />} />
        </Routes>
      </Router>
    </Provider>
  );
}

export default App;
