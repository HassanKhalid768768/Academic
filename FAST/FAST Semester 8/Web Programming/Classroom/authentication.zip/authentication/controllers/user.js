import { addUser, getAllUsers, getUserByEmail } from "../db/operations/user.js";
import { generateAccessToken } from "../utilities/jwt.js";
import { comparePassword, encryptPassword } from "../utilities/passwordEncryption.js";

// Add user with role
export const addUserController = async (req, res) => {
  try {
    const { name, email, password, role = "user" } = req.body; // Default role is "user"
    
    // Check if the role is valid
    if (!["user", "admin", "manager"].includes(role)) {
      return res
        .status(400)
        .json({ success: false, message: "Invalid role provided" });
    }

    const hashedPassword = await encryptPassword(password);
    await addUser(name, email, hashedPassword, role);  // Add role to the DB
    return res
      .status(201)
      .json({ success: true, message: "User added successfully" });
  } catch (error) {
    console.log(error);
    if (error.code === 11000)
      return res
        .status(409)
        .json({ success: false, message: "Email cannot be duplicate." });
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

// Login user and return the token with the role
export const loginUserController = async (req, res) => {
  try {
    const user = await getUserByEmail(req.body.email);

    if (!user) {
      return res
        .status(401)
        .json({ status: false, message: "Invalid user credentials" });
    }

    const passwordMatched = await comparePassword(req.body.password, user.password);
    if (passwordMatched) {
      const { accessToken, expiresAt } = generateAccessToken(user._id);

      return res.status(200).json({
        success: true,
        message: "User logged in successfully",
        accessToken,
        expiresAt,
        role: user.role,  // Send token to front end to save in local storge
      });
    } else {
      return res
        .status(401)
        .json({ status: false, message: "Invalid user credentials" });
    }
  } catch (error) {
    console.log(error);
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};

// Get all users — restricted to admins only
export const getAllUsersController = async (req, res) => {
  try {
    const user = req.user; // The user object comes from authenticationMiddleware

    // Check if the user has the correct role (admin)
    // You think this is needed here?
    if (user.role !== "admin") {
      return res
        .status(403)
        .json({ success: false, message: "Access denied. Admin role required." });
    }

    const allUsers = await getAllUsers();
    return res.status(200).json(allUsers);
  } catch (error) {
    return res
      .status(500)
      .json({ success: false, message: "Internal server error" });
  }
};
