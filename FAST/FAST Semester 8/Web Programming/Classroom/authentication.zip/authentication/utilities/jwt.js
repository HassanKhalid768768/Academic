import jwt from "jsonwebtoken";

const TOKEN_SECRET = "!l#z9QR5Ry7uQ3Qwqrh6rt";
//This is the secret key used to sign and verify tokens.
//In production, this should be stored in an environment variable (e.g., process.env.TOKEN_SECRET), not hardcoded.

export const generateAccessToken = (user) => {
  const accessToken = jwt.sign(
    {
      userId: user._id,
      role: user.role,
    },
    TOKEN_SECRET,
    { expiresIn: "1d" }
  );

  const decoded = jwt.decode(accessToken);
  const expiresAt = new Date(decoded.exp * 1000).toISOString();

  return { accessToken, expiresAt };
};


export const verifyAccessToken = (accessToken) => {
  // This throws if the token is invalid or expired
  const tokenPayload = jwt.verify(accessToken, TOKEN_SECRET);

  // Return the full payload: includes userId, role, exp, etc.
  return tokenPayload;
};
