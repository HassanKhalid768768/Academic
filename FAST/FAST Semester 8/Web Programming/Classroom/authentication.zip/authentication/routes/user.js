import express from "express";
import {
  addUserController,
  getAllUsersController,
  loginUserController,
} from "../controllers/user.js";
import {
  authenticationMiddleware,
  authorizationMiddleware
} from "../middleware/auth.js"; // assuming both are defined here

const userRoutes = express.Router();

// Public route — no token needed
userRoutes.post("/login", loginUserController);

// Protected route — must be logged in AND authorized (e.g., admin)
userRoutes.post("/add", authenticationMiddleware, authorizationMiddleware("admin"), addUserController);

// Protected route — must be logged in AND authorized (e.g., admin)
userRoutes.get("/all", authenticationMiddleware, authorizationMiddleware("admin"), getAllUsersController);

export default userRoutes;
