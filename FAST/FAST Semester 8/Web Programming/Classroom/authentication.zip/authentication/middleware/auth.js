import jwt from "jsonwebtoken";
import { verifyAccessToken } from "../utilities/jwt.js";

const extractTokenFromReqObj = (req) => {
  const authHeader = req.headers.authorization;
  //Authorization: Bearer <access_token>
  return !authHeader || authHeader.split(" ").length < 2
    ? null
    : authHeader.split(" ")[1];
  // !authHeader → Checks if the Authorization header is missing. 
  //authHeader.split(" ").length < 2 → Checks if the header doesn't contain at least two parts (e.g., it should look like "Bearer <token>").
  // return <token>

};

//The next parameter in authenticationMiddleware = (req, res, next) is how Express middleware works. It's a function that passes control to the next middleware or route handler in the chain.

export const authenticationMiddleware = (req, res, next) => {
  try {
    const accessToken = extractTokenFromReqObj(req);
    if (!accessToken) {
      return res
        .status(401)
        .json({ success: false, message: "Authorization token missing" });
    }

    const userPayload = verifyAccessToken(accessToken); // Full payload (userId, role, exp, etc.)

    req.user = userPayload; // Attach full user info to req object to use it
    next(); // Pass control to next middleware or controller
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      return res
        .status(401)
        .json({ success: false, message: "access token expired" });
    }

    return res
      .status(401)
      .json({ success: false, message: "invalid access token" });
  }
};

export const authorizationMiddleware = (requiredRole) => {
  return (req, res, next) => {
    try {
      const accessToken = extractTokenFromReqObj(req);

      if (!accessToken) {
        return res
          .status(401)
          .json({ success: false, message: "Authorization token missing" });
      }

      const userPayload = verifyAccessToken(accessToken); // returns full payload (must include `role`)

      if (!payload.role || payload.role !== requiredRole) {
        return res
          .status(403)
          .json({ success: false, message: "Access denied. Insufficient role" });
      }

      req.user = payload; // You can still attach it if needed later to use it
      next(); // Pass control to next middleware or controller
    } catch (error) {
      if (error instanceof jwt.TokenExpiredError) {
        return res
          .status(401)
          .json({ success: false, message: "Access token expired" });
      }

      return res
        .status(403)
        .json({ success: false, message: "Unauthorized. Invalid token or role" });
    }
  };
};
