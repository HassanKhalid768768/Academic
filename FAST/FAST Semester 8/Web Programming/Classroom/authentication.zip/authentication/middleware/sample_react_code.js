//login call 

const response = await fetch("/users/login", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
  },
  body: JSON.stringify({ email, password }),
});

const data = await response.json();

if (response.ok && data.success) {
  localStorage.setItem("accessToken", data.accessToken);
  localStorage.setItem("expiresAt", data.expiresAt);
  localStorage.setItem("userRole", data.role);

  return { success: true, role: data.role };
} 
//That way, the token is available for future authenticated requests by including it in the Authorization header like:


// Response format sent to frontend to store in localStorage:
/*
{
  "success": true,
  "message": "User logged in successfully",
  "accessToken": "<JWT_TOKEN_STRING>",
  "expiresAt": "2025-05-01T10:45:00.000Z",
  "role": "admin"
}
*/



//show call users call from front end
// 
const token = localStorage.getItem("accessToken"); // or wherever you stored the JWT

fetch("http://localhost:5000/api/users/all", {
  method: "GET",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`, // This is key
  },
})
  .then((res) => res.json())
  .then((data) => {
    console.log("Protected data:", data);
  })
  .catch((err) => {
    console.error("Error:", err);
  });


 