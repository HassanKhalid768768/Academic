import mongoose from "mongoose";
import express from "express";
import { addUser, getAllUsers } from "./db/operations/user.js";
import { getPosts } from "./db/operations/post.js";
import userRoutes from "./routes/user.js";
import { mongoConnect } from "./db/config.js";

const start = async () => {
  try {
    await mongoConnect();
    const app = express();
    const port = 3000;

    app.use(express.json());

    //all apis starting with /user will be handled by userRoutes (router middleware)
    app.use("/user", userRoutes);
    //  app.use("/student", studentRoutes);
    //  app.use("/movies", moviesRoutes);

    app.get("/student/:rollNumber/course/:courseId", (req, res) => {
      console.log(req.params);
      console.log(req.query);
      //call crud operation and pass path and query parameters to that crud operation
      //...
      return res.status(200).send("Hello World!");
    });

    app.post("/student", (req, res) => {
      console.log(req.body);
      //call crud operation and pass data in the body to that crud operation
      //...
      return res
        .status(200)
        .json({ success: true, message: "student added successfully" });
    });

    app.listen(port, () => {
      console.log(`app started listening on port ${port}`);
    });
  } catch (error) {
    console.log(error);
  } finally {
    //mongoose.connection.close();
  }
};

start();
