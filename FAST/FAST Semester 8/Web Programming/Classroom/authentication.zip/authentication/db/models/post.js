import mongoose from "mongoose";

// Define the schema for a User
const postSchema = new mongoose.Schema(
  {
    by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
    content: {
      type: String,
      required: true,
    },
  },
  { timestamps: true }
);

// Create a model based on the schema
const Post = mongoose.model("Post", postSchema);
export default Post;
