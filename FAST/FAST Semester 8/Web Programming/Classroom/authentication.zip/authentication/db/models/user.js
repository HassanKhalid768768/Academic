import mongoose from "mongoose";

// Define the schema for a User
const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
      unique: true,
      match: /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/,
    },
    password: {
      type: String,
      required: true,
    },
    role: {
      type: String,
      enum: ["user", "admin", "manager"],  // You can add more roles as needed
      default: "user",  // Default role for new users
    },
  },
  { timestamps: true }
);

// Create a model based on the schema
const User = mongoose.model("User", userSchema);
export default User;
