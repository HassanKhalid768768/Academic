import Post from "../models/post.js"

export const getPosts=async()=>{
    return await Post.find();
}