import User from "../models/user.js";

export const addUser = async (name, email, password) => {
  return await User.create({ name, email, password });
};

export const getUserByEmail = async (email) => {
  return await User.findOne({ email });
};

export const getAllUsers = async () => {
  return await User.find();
};
