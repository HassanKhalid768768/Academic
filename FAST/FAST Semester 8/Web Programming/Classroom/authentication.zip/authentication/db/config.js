
import mongoose from "mongoose";

export const mongoConnect=()=> mongoose.connect("mongodb://localhost:27017/temp");