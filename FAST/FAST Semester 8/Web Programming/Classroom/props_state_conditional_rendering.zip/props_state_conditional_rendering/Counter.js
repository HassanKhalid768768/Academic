import { useState } from "react";

function Counter() {
  const [count, setCount] = useState(0);

  return (
    <div className="p-4 border rounded-lg text-center shadow-lg w-64 mx-auto mt-5">
      <h2 className="text-xl font-bold">Counter</h2>
      <p className="text-2xl my-3">{count}</p>
      <button className="bg-blue-500 text-white px-3 py-1 rounded m-1" onClick={() => setCount(count + 1)}>+</button>
      <button className="bg-red-500 text-white px-3 py-1 rounded m-1" onClick={() => setCount(count - 1)}>-</button>
    </div>
  );
}

export default Counter;