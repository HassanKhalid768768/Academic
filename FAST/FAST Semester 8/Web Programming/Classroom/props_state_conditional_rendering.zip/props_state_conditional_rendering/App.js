import List from "./List";
import Counter from "./Counter";

export default function App() {
  return (
    <div className="flex flex-col items-center">
      <List title="Simple List">
        <p className="text-gray-600">Click the button to add items.</p>
      </List>
      <Counter />
    </div>
  );
}