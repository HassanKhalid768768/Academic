import { useState } from "react";

function List({ title, children }) {
  const [items, setItems] = useState([]);

  const addItem = () => {
    setItems(prevItems => [...prevItems, `Item ${prevItems.length + 1}`]);
  };

  return (
    <div className="p-4 border rounded-lg text-center shadow-lg w-64 mx-auto mt-5">
      <h2 className="text-xl font-bold">{title}</h2>
      {children}
      <ul className="my-3">
        {items.map((item, index) => (
          <li key={index} className="text-lg">{item}</li>
        ))}
      </ul>
      <button className="bg-green-500 text-white px-3 py-1 rounded m-1" onClick={addItem}>Add Item</button>
    </div>
  );
}

export default List;