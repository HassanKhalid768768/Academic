const mongoose = require("mongoose");

const ItemSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, "Name is required"]
  },
  quantity: {
    type: Number,
    required: [true, "Quantity is required"]
  }
});

module.exports = mongoose.model("Item", ItemSchema);
